<?php

$q=$_POST["q"];
$answer1=$_POST['answer1'];
$answer2=$_POST['answer2'];
$answer3=$_POST['answer3'];
$answer4=$_POST['answer4'];

$HOST = "localhost";
$USERNAME = "root";
$PASSWORD = "";
$DATABASE_NAME = "vpmthane";

$mysqli = new mysqli($HOST,$USERNAME,$PASSWORD,$DATABASE_NAME);
$sql = "INSERT INTO questions(questions,answer1,answer2,answer3,answer4) VALUES(?,?,?,?,?)";
//$response = 
//echo $response;
$query = $mysqli->prepare($sql);
if ($mysqli->error) {
    try {   
        throw new Exception("MySQL error $mysqli->error <br> Query:<br> $query", $msqli->errno);   
    } catch(Exception $e ) {
        echo "Error No: ".$e->getCode(). " - ". $e->getMessage() . "<br >";
        echo nl2br($e->getTraceAsString());
    }
}
$query -> bind_param('sssss',$q,$answer1,$answer2,$answer3,$answer4);
$query->execute() or die($mysqli->error);
$response ="Rows Inserted.\n".$query->affected_rows;
echo $response;


?>
