<?php
session_start();
include("dbcon.php");
//$counter = $_POST['counter'];
$counter=0;
$query="select * from t01111 LIMIT ".$counter.",".($counter+2);
$result = $mysqli->query($query);
while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
{
	echo "<label>".$row['questions']."</label><br /><input type='radio' name='".$row[id]."' value='1' />".$row[answer1]."<br /><input type='radio' name='".$row[id]."' value='2' />".$row[answer2]."<br /><input type='radio' name='".$row[id]."' value='3' />".$row[answer3]."<br /><input type='radio' name='".$row[id]."' value='4' />".$row[answer4]."<br/>";
}

?>