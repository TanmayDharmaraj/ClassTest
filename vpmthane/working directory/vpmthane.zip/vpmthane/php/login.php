<?php
session_start();
$username=$_POST['username'];
$password=$_POST['password'];

if($username&&$password)
{
	include('dbcon.php');
	$query= mysql_fetch_array(mysql_query("SELECT * FROM users WHERE username='$username'"));
	$user=$query['username'];
	$pass=$query['password'];
	if($username==$user && md5($password)==$pass)
	{	
		echo"Correct Password <br/>";
		$_SESSION['username']=$user;
		echo"Click <a href='index.php'>here</a> to go back to home page";
	}
	else
	{
		die("Incorrect Username/Password");
	}
	
}
else
{
	die("Please enter a username and passowrd");
}

?>

