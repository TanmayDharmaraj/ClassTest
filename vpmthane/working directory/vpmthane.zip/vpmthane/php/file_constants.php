<?php
$host="localhost";
$user="root";
$pass="";
$db="vpmthane";
?>
