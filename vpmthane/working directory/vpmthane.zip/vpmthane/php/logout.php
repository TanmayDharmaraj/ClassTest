<?php
session_start();
session_destroy();
echo'Logout Successful.Click <a href="index.php">here</a> to return'
?>