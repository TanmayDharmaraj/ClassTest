<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Class Test</title>
    
    <!--<link rel="stylesheet" href="style.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="chat.js"></script>-->
</head>
<body>
<!-- Registration and login submission -->
	<div id="login">
	<form action="login.php" method="POST">
		<a href="register.php">Register</a>	
			Username: <input type="text" name="username"></input>
			Password: <input type="password" name="password"></input>
			<input type="submit" value="Log In"></input>
	</form>
	</div>
<!-- End Registration and login submission -->
	

	
	

</body>
</html>
